import { useEffect, useState } from "react";

// Sayaç 22 Kasım 2026, 22:32 Türkiye saatinden itibaren ilerler.
const BASLANGIC = new Date("2026-11-22T22:32:00+03:00").getTime();

function gecenSure() {
  const fark = Math.max(0, Date.now() - BASLANGIC);
  return {
    basladi: Date.now() >= BASLANGIC,
    gun: Math.floor(fark / 86_400_000),
    saat: Math.floor((fark / 3_600_000) % 24),
    dakika: Math.floor((fark / 60_000) % 60),
    saniye: Math.floor((fark / 1_000) % 60),
  };
}

export default function App() {
  const [sure, setSure] = useState(gecenSure);

  useEffect(() => {
    const timer = window.setInterval(() => setSure(gecenSure()), 1000);
    return () => window.clearInterval(timer);
  }, []);

  return (
    <div className="site-shell">
      <header className="site-header">
        <a className="wordmark" href="#baslangic" aria-label="Bir ihtimal, başa dön">
          bir ihtimal<span>.</span>
        </a>
        <a className="header-link" href="#not">Küçük bir not <span aria-hidden="true">↗</span></a>
      </header>

      <main>
        <section className="hero" id="baslangic" aria-labelledby="hero-title">
          <div className="hero-image" role="img" aria-label="Mavi saatlerde sakin bir deniz ve deniz feneri" />
          <div className="hero-shade" />
          <div className="hero-content">
            <p className="hero-kicker"><span className="kicker-line" /> SANA KÜÇÜK BİR NOT</p>
            <h1 id="hero-title">İyi ki<br /><em>denk geldik.</em></h1>
            <p className="hero-description">Bazı insanlarla konuşmak, günün en güzel kısmı oluyor. Sen de benim için öylesin.</p>
            <a className="primary-button" href="#not">Devam et <span aria-hidden="true">↗</span></a>
          </div>
          <div className="hero-bottom" aria-hidden="true"><span>Biraz aşağı kaydır</span><span className="down-arrow">↓</span></div>
        </section>

        <section className="note-section" id="not" aria-labelledby="note-title">
          <div className="section-number">01 / KÜÇÜK BİR NOT</div>
          <div className="note-content">
            <p className="section-kicker">BİZİM İÇİN BİR TARİH</p>
            <p className="date-line">22 Kasım 2026</p>
            <p className="date-caption">Şu saatten itibaren beraberiz.</p>
            <div className="time-together" aria-label={sure.basladi ? `Beraber geçen süre: ${sure.gun} gün, ${sure.saat} saat, ${sure.dakika} dakika, ${sure.saniye} saniye` : "Beraberlik sayacı henüz başlamadı"}>
              <p className="time-heading">{sure.basladi ? "BERABER GEÇEN ZAMAN" : "SAYAÇ O AN BAŞLAYACAK"}</p>
              <div className="time-values">
                {([
                  [sure.gun, "GÜN"],
                  [sure.saat, "SAAT"],
                  [sure.dakika, "DAKİKA"],
                  [sure.saniye, "SANİYE"],
                ] as const).map(([value, label]) => (
                  <div className="time-unit" key={label} aria-hidden="true">
                    <span className="time-number">{String(value).padStart(2, "0")}</span>
                    <span className="time-label">{label}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="note-divider" />
            <h2 id="note-title">Şimdilik<br /><em>birkaç cümle.</em></h2>
            <div className="note-text">
              <p>Seninle konuşurken zamanın nasıl geçtiğini pek anlamıyorum. En sıradan konu bile seninle daha eğlenceli oluyor.</p>
              <p>Henüz her şeyin başındayız, biliyorum. O yüzden büyük laflar etmeyeceğim. Sadece seni tanımaktan gerçekten keyif aldığımı söylemek istedim.</p>
              <p className="last-line">Bakalım, bu hikâye bizi nereye götürecek.</p>
            </div>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <span>bir ihtimal<span className="footer-dot">.</span></span>
        <span>Senin için, içtenlikle.</span>
      </footer>
    </div>
  );
}
